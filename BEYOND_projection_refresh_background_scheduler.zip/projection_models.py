"""
SQLAlchemy models used by the projection refresh queue.

This module defines `ProjectionRefreshJob`, a database model representing a pending refresh
task for the public trust explorer projections.  Each job stores the reason for the
refresh, optional identifiers (actor or evidence), and its current processing state.

Integrate this model into your existing `models` module or import it directly when
creating an Alembic migration.  You will need to run a migration to create the
`projection_refresh_jobs` table after adding this model.
"""

from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime

from database import Base


class ProjectionRefreshJob(Base):
    """Represents a queued projection refresh job.

    A projection refresh job describes a request to rebuild some or all public
    projections.  The `reason` field allows the calling code to specify why the
    refresh is needed (e.g. ``full`` for a full rebuild, ``moderation`` for a
    moderation-triggered update, ``trust_recompute`` when trust scores were
    recomputed, etc.).  Optional ``actor_id`` and ``evidence_id`` fields can
    scope the refresh to a particular actor or evidence item.  Jobs are
    processed in FIFO order by the background worker.
    """

    __tablename__ = "projection_refresh_jobs"

    id = Column(Integer, primary_key=True, index=True)
    reason = Column(String, nullable=False)
    actor_id = Column(Integer, nullable=True)
    evidence_id = Column(Integer, nullable=True)
    status = Column(String, default="pending", nullable=False)
    attempts = Column(Integer, default=0, nullable=False)
    max_attempts = Column(Integer, default=3, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
    )

    def __repr__(self) -> str:  # pragma: no cover - repr isn't tested
        return (
            f"<ProjectionRefreshJob id={self.id} reason={self.reason}"
            f" status={self.status} attempts={self.attempts}/{self.max_attempts}>"
        )