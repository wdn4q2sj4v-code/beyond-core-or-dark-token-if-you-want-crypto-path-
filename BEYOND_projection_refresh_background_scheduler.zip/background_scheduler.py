"""
Background worker for projection refresh jobs.

This module defines a coroutine that runs in the background and processes
queued projection refresh jobs.  It repeatedly polls the database for
pending jobs, executes the projection refresh logic on the first job found
and either marks the job as completed or retries it, depending on the
outcome.  Failed jobs are retried up to ``max_attempts`` times.

To use this worker, import and call ``start_background_workers`` from your
FastAPI startup event.  The worker uses ``asyncio.get_event_loop()`` to
schedule a long‐running task; ensure that your runtime has an event loop
available (which is the case when using Uvicorn or Hypercorn).
"""

import asyncio
import logging
from typing import Callable

from sqlalchemy.orm import Session

from database import SessionLocal
from services.projection_refresh_queue import (
    fetch_next_pending_job,
    record_attempt,
    mark_job_as_completed,
    mark_job_as_failed,
)
from services.projection_refresh import refresh_projections


logger = logging.getLogger("projection_refresh_worker")
logger.setLevel(logging.INFO)


async def projection_refresh_worker(
    interval_seconds: int = 10,
    *,
    refresh_fn: Callable[[Session, str, int, int], None] | None = None,
) -> None:
    """Continuously process queued projection refresh jobs.

    Args:
        interval_seconds: Number of seconds to wait between polling cycles.
        refresh_fn: Optional override for the projection refresh function.
            If provided, this callable will be invoked instead of
            ``refresh_projections``.  The signature should be
            ``(db: Session, reason: str, actor_id: int | None, evidence_id: int | None)``.

    The worker fetches the next pending job (FIFO order), runs the refresh logic
    and updates the job's status accordingly.  Exceptions during refresh will
    cause the job to be retried until its ``attempts`` counter reaches
    ``max_attempts``.  After each iteration the worker sleeps for
    ``interval_seconds`` before polling again.
    """
    refresh = refresh_fn or refresh_projections
    while True:
        db: Session = SessionLocal()
        try:
            job = fetch_next_pending_job(db)
            if job is not None:
                logger.info(
                    "Processing projection refresh job %s (attempt %s/%s)",
                    job.id,
                    job.attempts + 1,
                    job.max_attempts,
                )
                try:
                    refresh(db, job.reason, job.actor_id, job.evidence_id)
                    mark_job_as_completed(db, job)
                    logger.info(
                        "Completed projection refresh job %s (%s)",
                        job.id,
                        job.reason,
                    )
                except Exception as exc:
                    logger.exception(
                        "Error while processing projection refresh job %s: %s",
                        job.id,
                        exc,
                    )
                    record_attempt(db, job)
                    if job.attempts >= job.max_attempts:
                        mark_job_as_failed(db, job)
                        logger.error(
                            "Projection refresh job %s exceeded max attempts and was marked as failed",
                            job.id,
                        )
            # commit any changes and close session
            db.commit()
        finally:
            db.close()
        await asyncio.sleep(interval_seconds)


def start_background_workers(app) -> None:
    """Launch background worker tasks on application startup.

    Call this function inside the FastAPI startup event to schedule
    the projection refresh worker.  For example:

    ```python
    app = FastAPI()

    @app.on_event("startup")
    async def startup_event():
        start_background_workers(app)
    ```

    Args:
        app: The FastAPI application instance; included for future extension.
    """
    loop = asyncio.get_event_loop()
    loop.create_task(projection_refresh_worker())