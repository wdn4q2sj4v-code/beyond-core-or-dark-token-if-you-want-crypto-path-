# Projection Refresh Background Scheduler and Retry Queue

This package provides modules to integrate a background scheduler and retry queue into your BEYOND system so that projection refreshes can be processed both inline and asynchronously.  It is intended to be integrated into the existing BEYOND backend and does **not** replace any of your existing modules.  Instead, it offers a drop‐in job queue and worker that you can hook into your current projection refresh service.

## Components

- **`projection_models.py`** – defines a new SQLAlchemy model `ProjectionRefreshJob` representing tasks in the refresh queue.  You should generate an Alembic migration after adding this model so the corresponding table (`projection_refresh_jobs`) exists in your database.
- **`projection_refresh_queue.py`** – provides helper functions to enqueue tasks, fetch the next pending job, increment the attempt counter and mark jobs as completed or failed.  It assumes you already have a SQLAlchemy session factory available.
- **`background_scheduler.py`** – contains a coroutine `projection_refresh_worker` that continuously processes pending jobs from the queue.  It catches exceptions, increments the retry counter and marks jobs as failed once the maximum number of attempts has been reached.  A helper `start_background_workers` starts the worker on application startup.

## Integration Steps

1. **Add the model and migrate the database:**
   - Copy `ProjectionRefreshJob` from `projection_models.py` into your `models` module or import it directly.
   - Create an Alembic revision that adds the `projection_refresh_jobs` table to your database.  Example:
     ```python
     # Example migration snippet
     from alembic import op
     import sqlalchemy as sa

     def upgrade():
         op.create_table(
             'projection_refresh_jobs',
             sa.Column('id', sa.Integer, primary_key=True),
             sa.Column('reason', sa.String, nullable=False),
             sa.Column('actor_id', sa.Integer, nullable=True),
             sa.Column('evidence_id', sa.Integer, nullable=True),
             sa.Column('status', sa.String, nullable=False, default='pending'),
             sa.Column('attempts', sa.Integer, nullable=False, default=0),
             sa.Column('max_attempts', sa.Integer, nullable=False, default=3),
             sa.Column('created_at', sa.DateTime, nullable=False),
             sa.Column('updated_at', sa.DateTime, nullable=False),
         )

     def downgrade():
         op.drop_table('projection_refresh_jobs')
     ```

2. **Use the queue in your hooks:**
   - Instead of always calling your projection refresh service directly from hooks such as `on_moderation_completed` or `on_trust_recomputed`, decide when a refresh should be immediate or queued.  For small or critical updates, you can continue to call `refresh_projections` synchronously.  For large or potentially expensive updates (e.g., full rebuilds), call `enqueue_refresh_job` instead.  Example:
     ```python
     from services.projection_refresh_queue import enqueue_refresh_job

     def on_moderation_completed(db: Session, actor_id: int, evidence_id: int):
         # For small refreshes, run inline
         refresh_projections(db, reason='moderation', actor_id=actor_id, evidence_id=evidence_id)
         # For full rebuilds, enqueue:
         enqueue_refresh_job(db, reason='full', actor_id=actor_id, evidence_id=evidence_id)
     ```

3. **Start the background worker:**
   - In your `main.py` (or wherever you initialise FastAPI), import and call `start_background_workers` during the startup event:
     ```python
     from fastapi import FastAPI
     from services.background_scheduler import start_background_workers

     app = FastAPI()

     @app.on_event('startup')
     async def startup_event():
         start_background_workers(app)
     ```
   - The worker runs indefinitely in its own task and processes queued jobs every few seconds.  Adjust the sleep interval in `projection_refresh_worker` if necessary.

4. **Monitor and maintain:**
   - You can view and manage queued jobs via the `projection_refresh_jobs` table.  Consider exposing administrative endpoints to inspect pending or failed jobs.
   - If you need to change the maximum number of retry attempts, override the `max_attempts` parameter when enqueuing jobs.
   - Add logging inside `projection_refresh_worker` to make it easier to debug failed refreshes.

## Scheduling Logic

The provided worker uses `asyncio` to loop through pending jobs.  Whenever a job is available, it calls your existing `refresh_projections` service with the job parameters.  If `refresh_projections` raises an exception, the worker increments the job’s `attempts` counter.  Once `attempts` reaches `max_attempts`, the job is marked as `failed`.  Otherwise, it remains `pending` and will be retried on the next loop.

This approach allows you to run the refresh logic in the background without blocking request handlers while providing a retry mechanism to handle transient failures.