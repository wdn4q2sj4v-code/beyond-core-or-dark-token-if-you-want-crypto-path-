"""
Queue management helpers for projection refresh jobs.

These helpers wrap basic queue operations such as creating a new refresh job,
fetching the next pending job, incrementing the retry counter and marking a job
as completed or failed.  They assume the existence of a SQLAlchemy session
factory (``SessionLocal``) and the ``ProjectionRefreshJob`` model.  Feel free
to adapt these functions to match your project's database infrastructure.
"""

from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from .projection_models import ProjectionRefreshJob


def enqueue_refresh_job(
    db: Session,
    *,
    reason: str,
    actor_id: Optional[int] = None,
    evidence_id: Optional[int] = None,
    max_attempts: int = 3,
) -> ProjectionRefreshJob:
    """Create and persist a new projection refresh job.

    Args:
        db: Active SQLAlchemy session.
        reason: Short string describing why the refresh is needed (e.g. ``"full"``,
            ``"moderation"`` or ``"trust_recompute"``).
        actor_id: Optional primary key of the actor triggering the refresh.
        evidence_id: Optional primary key of the evidence triggering the refresh.
        max_attempts: Maximum number of times the job will be attempted before
            being marked as failed.

    Returns:
        The newly created ``ProjectionRefreshJob`` instance.
    """
    job = ProjectionRefreshJob(
        reason=reason,
        actor_id=actor_id,
        evidence_id=evidence_id,
        status="pending",
        attempts=0,
        max_attempts=max_attempts,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


def fetch_next_pending_job(db: Session) -> Optional[ProjectionRefreshJob]:
    """Fetch the oldest pending refresh job or ``None`` if none exist.

    Args:
        db: Active SQLAlchemy session.

    Returns:
        A ``ProjectionRefreshJob`` if at least one job is pending, otherwise ``None``.
    """
    return (
        db.query(ProjectionRefreshJob)
        .filter(ProjectionRefreshJob.status == "pending")
        .order_by(ProjectionRefreshJob.created_at)
        .first()
    )


def record_attempt(db: Session, job: ProjectionRefreshJob) -> None:
    """Increment the attempt counter for a job.

    Args:
        db: Active SQLAlchemy session.
        job: Job whose attempt count should be incremented.
    """
    job.attempts += 1
    job.updated_at = datetime.utcnow()
    db.commit()


def mark_job_as_completed(db: Session, job: ProjectionRefreshJob) -> None:
    """Mark a job as completed and persist the change.

    Args:
        db: Active SQLAlchemy session.
        job: Job to mark as completed.
    """
    job.status = "completed"
    job.updated_at = datetime.utcnow()
    db.commit()


def mark_job_as_failed(db: Session, job: ProjectionRefreshJob) -> None:
    """Mark a job as failed and persist the change.

    Args:
        db: Active SQLAlchemy session.
        job: Job to mark as failed.
    """
    job.status = "failed"
    job.updated_at = datetime.utcnow()
    db.commit()